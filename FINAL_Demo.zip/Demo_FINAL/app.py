import streamlit as st

if 'page' not in st.session_state:
    st.session_state.page = "main"

if st.session_state.page == "main":
    from main import main
    main()

elif st.session_state.page == "QA":
    from QA import chat
    chat()

elif st.session_state.page == "info":
    from info import info
    info()

