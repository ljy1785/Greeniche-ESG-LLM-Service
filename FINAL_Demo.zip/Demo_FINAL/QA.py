import streamlit as st
from rag import initialize_rag, ask_question
from langchain.memory import ConversationBufferMemory
from langchain_upstage import UpstageGroundednessCheck
from docparser import parse_document

UPSTAGE_API_KEY = "up_cZqby2IshCaBBPLAETUOuEFnw0PIp"

def chat():
    st.title("ESG 공시 변환 챗봇 그리니치")
    st.write("문서를 업로드하고 ESG 공시 정보에 대해 물어보세요:)")

    # 사이드바에 제목 추가
    st.sidebar.title("대화 기록")

    # 세션 상태 초기화
    if 'parsed_text' not in st.session_state:
        st.session_state.parsed_text = None
    if 'qa_chain' not in st.session_state:
        st.session_state.qa_chain = None
    if 'messages' not in st.session_state:  # 메모리 초기화
        st.session_state.messages = []
    if 'current_question' not in st.session_state:
        st.session_state.current_question = None  # 현재 질문 상태 초기화

    # 메모리 상태 초기화 (없을 때만)
    if 'memory' not in st.session_state:
        st.session_state.memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

    # 메모리 초기화 버튼
    if st.sidebar.button('메모리 초기화'):
        st.session_state.memory = ConversationBufferMemory()  # 메모리 초기화
        st.session_state.parsed_text = None  # 문서가 다시 업로드되도록 초기화
        st.session_state.qa_chain = None     # 질의응답 체인을 초기화
        st.session_state.messages = []       # 메시지 초기화
        st.session_state.current_question = None  # 질문 초기화
        st.success('메모리가 초기화되었습니다.')

    # 현재 메모리 상태 표시
    current_buffer = st.session_state.memory.buffer
    st.sidebar.write('현재 메모리 상태:', current_buffer)

    # 파일 업로드 처리
    uploaded_file = st.file_uploader("Upload a document (.txt, .md, .pdf)", type=("txt", "md", "pdf"))

    # 파일 업로드 시마다 상태를 초기화하여 새 문서가 제대로 처리되도록 함
    if uploaded_file:
        with st.spinner("문서 분석 중 ..."):
            parsed_text, raw_data = parse_document(uploaded_file)
            if parsed_text:  # 파싱 성공 시에만 상태 업데이트
                st.session_state.parsed_text = parsed_text
                st.session_state.qa_chain = initialize_rag(st.session_state.parsed_text)  # 문서 변경 시 질의응답 체인도 다시 생성
                st.session_state.current_question = None  # 새 문서가 업로드되면 질문 상태 초기화
                st.session_state.messages = []  # 메시지 초기화
                st.success("문서 업로드에 성공했습니다!")
                st.write("파싱된 텍스트:")
                st.text_area("Parsed Text", st.session_state.parsed_text, height=300)  # 파싱된 텍스트 출력

            else:
                st.warning("파싱된 텍스트가 없습니다.")
                st.json(raw_data)  # 디버깅을 위해 원본 데이터 출력

    # 질문 입력을 받는 부분
    if st.session_state.parsed_text is not None and st.session_state.qa_chain is not None:
        # 질문을 입력받기 위한 텍스트 영역
        question = st.text_area("챗봇 그리니치에게 질문하세요:", placeholder="궁금하신 ESRS나 GRI 지표에 대해 질문하세요!", key="question_input")

        # 현재 상태 출력 (디버깅용)
        st.write("현재 질문 상태:", st.session_state.current_question)

        if st.button("질문 제출"):
            st.session_state.current_question = question  # 현재 질문 상태 저장
            st.write("질문이 제출되었습니다:", st.session_state.current_question)  # 질문 상태 출력

    # 질문이 입력되었을 때 답변 생성
    if st.session_state.current_question:
        with st.spinner("답변 생성중...."):
            # Groundedness check 반복
            groundedness_check = UpstageGroundednessCheck(upstage_api_key=UPSTAGE_API_KEY)
            is_grounded = False
            response = ""

            while not is_grounded:
                response = ask_question(st.session_state.qa_chain, st.session_state.current_question)
                
                # Groundedness check
                request_input = {
                    "context": st.session_state.parsed_text,  # 파싱된 텍스트를 명시적으로 넣어줌
                    "answer": response,
                }

                try:
                    groundedness_response = groundedness_check.invoke(request_input)
                    if "grounded" in groundedness_response:
                        st.success("해당 ESG 지표를 참고한 답변입니다.")
                        is_grounded = True  # Grounded 상태로 변경
                    elif "notGrounded" in groundedness_response or "notSure" in groundedness_response:
                        st.warning("출처가 불분명한 답변입니다. 다시 답변을 생성합니다!")
                        # Grounded 상태가 아닐 경우, 새로운 답변을 생성하도록 루프를 계속 돌림
                except Exception as e:
                    st.error(f"Groundedness 확인 중 오류 발생: {str(e)}")
                    break  # 오류 발생 시 루프 종료

        # 최종 응답 출력
        st.write("그리니:")
        st.markdown(response)

        # 메모리 상태에 질문과 답변 저장
        st.session_state.memory.save_context({"input": st.session_state.current_question}, {"output": response})

        # 질문과 답변을 메시지에 저장
        st.session_state.messages.append({"role": "user", "content": st.session_state.current_question})
        st.session_state.messages.append({"role": "assistant", "content": response})

        # 상태 출력
        st.write("질문과 답변:", st.session_state.messages)

    # 이전 대화 기록 표시
    if "messages" in st.session_state:
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                if message["role"] == "assistant":
                    st.markdown(f"**그리니치:** {message['content']}")
                else:
                    st.markdown(message['content'])

    if st.button("뒤로가기"):
        st.session_state.page = "main"