import streamlit as st

def main():
    # 페이지 제목과 로고
    st.set_page_config(page_title="그리니치", layout="wide")

    # 상단의 메뉴바
    st.markdown("""
        <style>
        .menu-bar {
            display: flex;
            justify-content: space-between;
            background-color: #f0f0f0;
            padding: 10px 20px;
            border-bottom: 1px solid #ddd;
        }
        .menu-item {
            font-size: 18px;
            margin-right: 20px;
            font-weight: bold;
            color: #333;
        }
        .menu-item:last-child {
            margin-right: 0;
        }
        .center-content {
            text-align: center;
            margin-top: 50px;
        }
        .center-content img {
            margin: 30px 0;
        }
        .btn-group {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .btn-group button {
            margin: 0 10px;
            padding: 10px 20px;
            font-size: 16px;
        }
        </style>
    """, unsafe_allow_html=True)

    # 메뉴바
    st.markdown("""
        <div class="menu-bar">
            <div class="menu-item">그리니치 Greeniche</div>
        </div>
    """, unsafe_allow_html=True)

    # 중앙 컨텐츠
    st.markdown("""
        <div class="center-content">
            <h2>ESG 지표 변환 AI 서비스</h2>
            <div class="btn-group">
    """, unsafe_allow_html=True)

    st.image("greeniche.jpg", width=100, use_column_width=True)

    col1, col2 = st.columns([1, 1])  # 1:1 비율의 두 개 열 생성

    with col1:
        if st.button('지표 변환'):
            st.session_state.page = 'QA'

    with col2:
        if st.button('지표 검색'):
            st.session_state.page = 'info'
