import streamlit as st
import os
from main import main

def info():
    
    st.title("ESG 공시 정보 확인")

    pdf_dir = "GRI"
    pdf_files = [f for f in os.listdir(pdf_dir) if f.endswith('.pdf')]
    
    if pdf_files:
        st.write("다운로드 가능한 PDF 파일:")
        for pdf_file in pdf_files:
            # 다운로드 버튼 생성
            file_path = os.path.join(pdf_dir, pdf_file)
            with open(file_path, "rb") as f:
                st.download_button(
                    label=f"다운로드 {pdf_file}",
                    data=f,
                    file_name=pdf_file,
                    mime='application/pdf'
                )
    else:
        st.write("다운로드 가능한 PDF 파일이 없습니다.")

    if st.button("뒤로가기"):
        st.session_state.page = "main"

