import requests
import streamlit as st
from bs4 import BeautifulSoup

UPSTAGE_API_KEY = "up_cZqby2IshCaBBPLAETUOuEFnw0PIp"

def parse_document(uploaded_file):
    url = "https://api.upstage.ai/v1/document-ai/document-parse"
    headers = {"Authorization": f"Bearer {UPSTAGE_API_KEY}"}

    files = {"document": uploaded_file.getvalue()}
    try:
        response = requests.post(url, headers=headers, files=files)
        response.raise_for_status()

        data = response.json()

        # 'html' 컨텐츠가 있는지 확인하고 파싱
        if 'content' in data and 'html' in data['content']:
            raw_html = data['content']['html']
            
            # BeautifulSoup으로 HTML 태그 제거 후, 줄바꿈 대신 공백을 사용해 텍스트 추출
            soup = BeautifulSoup(raw_html, "html.parser")
            clean_text = soup.get_text(separator=" ").strip()

            return clean_text, data  # 파싱된 텍스트와 원본 데이터 반환
        else:
            st.error("문서가 제대로 파싱되지 않았습니다.")
            st.json(data)  # 디버깅을 위해 API 응답을 출력
            return None, data
    except requests.exceptions.RequestException as e:
        st.error(f"문서 파싱 중 오류 발생: {str(e)}")
        return None, None
