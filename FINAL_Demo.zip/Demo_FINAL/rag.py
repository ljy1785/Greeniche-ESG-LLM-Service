import streamlit as st
from langchain_pinecone import PineconeVectorStore
from langchain.chains import RetrievalQA
from langchain_upstage import UpstageEmbeddings, ChatUpstage
from langchain.prompts import PromptTemplate
from langchain.docstore.document import Document

UPSTAGE_API_KEY = "up_cZqby2IshCaBBPLAETUOuEFnw0PIp"
PINECONE_API_KEY = "4cf70d26-24f1-4438-8216-2e2b193835e3"
INDEX_NAME = "final2"
PINECONE_ENV = 'gcp-starter'


@st.cache_resource
def initialize_rag(parsed_text):
    # Define the prompt template for QA
    prompt = PromptTemplate(
        template="""당신은 유능한 ESG 전문가입니다. 다음 지시에 따라 질문에 대한 답변을 작성하세요.

        ### 지시:
        1. 아래 주어진 문서 내용을 기반으로 질문에 답변하세요. 외부 정보나 개인적인 의견은 포함하지 마십시오.
        2. 주요 키워드, 개념 및 패턴을 바탕으로 질문에 대한 구체적인 답변을 작성하세요. 숫자 데이터는 답변을 작성할 때 고려하지 마십시오.
        3. 관련 정보가 문서에 없는 경우, "문서에 해당 정보가 없습니다."라고 명시적으로 응답하세요.
        
    ### 문서:
    {context}

    ### 질문:
    {question}

    ### 답변:
    """,
        input_variables=["context", "question"]
    )

    # Initialize Upstage embeddings
    embeddings = UpstageEmbeddings(model="solar-embedding-1-large-query", upstage_api_key=UPSTAGE_API_KEY)

    # Convert the entire parsed text into a single document
    document = Document(page_content=parsed_text)

    # Initialize Pinecone vector store
    db = PineconeVectorStore(
        pinecone_api_key=PINECONE_API_KEY,
        index_name=INDEX_NAME,
        embedding=embeddings,
        text_key='chunk',  # The key used for storing the chunk
    )

    # Create the QA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=ChatUpstage(api_key=UPSTAGE_API_KEY, model="solar-pro", max_tokens=1000),
        chain_type="stuff",
        retriever=db.as_retriever(search_kwargs={"k": 1}),
        return_source_documents=True,
        chain_type_kwargs={"prompt": prompt}
    )

    return qa_chain


def ask_question(qa_chain, question):
    return qa_chain.invoke({"query": question})["result"]